from flask import Flask, render_template, request
import pickle

app = Flask(__name__)

with open(r'C:\Users\sruja\Desktop\ASSIGNMENT 8\spam_detection\model.pkl', 'rb') as f:
    model, vectorizer = pickle.load(f)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/check_spam', methods=['POST'])
def check_spam():
    email_text = request.form['email_text']
    email_vector = vectorizer.transform([email_text])
    prediction = model.predict(email_vector)[0]
    result = "Spam" if prediction == 1 else "Not Spam"
    
    return render_template('index.html', email_text=email_text, result=result)

if __name__ == '__main__':
    app.run(debug=True)
