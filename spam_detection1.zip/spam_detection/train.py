import os
import pickle
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.model_selection import train_test_split

def load_emails(folder_path):
    emails = []
    labels = []
    for filename in os.listdir(folder_path):
        with open(os.path.join(folder_path, filename), 'r', encoding='latin1') as file:
            email_content = file.read()
            emails.append(email_content)
            labels.append(1 if 'spmsg' in filename else 0)
    return emails, labels

train_path = r'C:\Users\sruja\Desktop\ASSIGNMENT 8\train_test_mails\train-mails'

emails, labels = load_emails(train_path)

vectorizer = TfidfVectorizer(stop_words='english', max_df=0.85)
X = vectorizer.fit_transform(emails)
y = labels

model = MultinomialNB()
model.fit(X, y)

with open('model.pkl', 'wb') as f:
    pickle.dump((model, vectorizer), f)

print("Model trained and saved successfully.")
