import os
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report

# Define paths to training and testing folders
train_folder = '/content/my_data/train_test_mails/train-mails'
test_folder = '/content/my_data/train_test_mails/test-mails'

# Function to load emails and labels from a given folder
def load_emails_from_folder(folder_path, label):
    emails = []
    labels = []
    for filename in os.listdir(folder_path):
        if filename.endswith(".txt"):
            file_path = os.path.join(folder_path, filename)
            with open(file_path, 'r', encoding='latin-1') as file:
                emails.append(file.read())
                labels.append(label)
    return emails, labels

# Load training data
spam_train_folder = os.path.join(train_folder, 'spam')
ham_train_folder = os.path.join(train_folder, 'ham')

spam_emails_train, spam_labels_train = load_emails_from_folder(spam_train_folder, label=1)
ham_emails_train, ham_labels_train = load_emails_from_folder(ham_train_folder, label=0)

train_emails = spam_emails_train + ham_emails_train
train_labels = spam_labels_train + ham_labels_train

# Load test data
spam_test_folder = os.path.join(test_folder, 'spam')
ham_test_folder = os.path.join(test_folder, 'ham')

spam_emails_test, spam_labels_test = load_emails_from_folder(spam_test_folder, label=1)
ham_emails_test, ham_labels_test = load_emails_from_folder(ham_test_folder, label=0)

test_emails = spam_emails_test + ham_emails_test
test_labels = spam_labels_test + ham_labels_test

# Vectorize email content
vectorizer = CountVectorizer()
X_train_transformed = vectorizer.fit_transform(train_emails)
X_test_transformed = vectorizer.transform(test_emails)

# Train Logistic Regression model
logistic_model = LogisticRegression(max_iter=1000)
logistic_model.fit(X_train_transformed, train_labels)

# Predict and evaluate
test_predictions = logistic_model.predict(X_test_transformed)
accuracy = accuracy_score(test_labels, test_predictions)

print(f"\nLogistic Regression Model Accuracy: {accuracy * 100:.2f}%")
print("\nClassification Report:\n", classification_report(test_labels, test_predictions))
