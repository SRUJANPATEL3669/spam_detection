import os
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, classification_report

# Define training and testing folders
train_folder = '/content/my_data/train_test_mails/train-mails'
test_folder = '/content/my_data/train_test_mails/test-mails'

# Function to load emails from a folder with a given label
def load_emails_from_folder(folder_path, label):
    emails = []
    labels = []
    for filename in os.listdir(folder_path):
        if filename.endswith(".txt"):
            file_path = os.path.join(folder_path, filename)
            with open(file_path, 'r', encoding='latin-1') as file:
                emails.append(file.read())
                labels.append(label)
    return emails, labels

# Load training data
spam_train_folder = os.path.join(train_folder, 'spam')
ham_train_folder = os.path.join(train_folder, 'ham')

spam_emails, spam_labels = load_emails_from_folder(spam_train_folder, label=1)
ham_emails, ham_labels = load_emails_from_folder(ham_train_folder, label=0)

train_emails = spam_emails + ham_emails
train_labels = spam_labels + ham_labels

# Load test data
spam_test_folder = os.path.join(test_folder, 'spam')
ham_test_folder = os.path.join(test_folder, 'ham')

spam_emails_test, spam_labels_test = load_emails_from_folder(spam_test_folder, label=1)
ham_emails_test, ham_labels_test = load_emails_from_folder(ham_test_folder, label=0)

test_emails = spam_emails_test + ham_emails_test
test_labels = spam_labels_test + ham_labels_test

# Vectorize email text using CountVectorizer
vectorizer = CountVectorizer()
X_train_transformed = vectorizer.fit_transform(train_emails)
X_test_transformed = vectorizer.transform(test_emails)

# Train Naive Bayes model
model = MultinomialNB()
model.fit(X_train_transformed, train_labels)

# Predict and evaluate
test_predictions = model.predict(X_test_transformed)
accuracy = accuracy_score(test_labels, test_predictions)

print(f"\nModel Accuracy: {accuracy * 100:.2f}%")
print("\nClassification Report:\n", classification_report(test_labels, test_predictions))
